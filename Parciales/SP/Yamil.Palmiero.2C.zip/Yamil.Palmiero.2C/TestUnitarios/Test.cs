﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

using Entidades;

namespace TestUnitarios
{
    [TestClass]
    public class Test
    {
        [TestMethod]
        [ExpectedException(typeof(ArchivoInvalidoException))]
        public void Verificar_Excepcion()
        {

        }

        [TestMethod]
        public void 
    }
}
