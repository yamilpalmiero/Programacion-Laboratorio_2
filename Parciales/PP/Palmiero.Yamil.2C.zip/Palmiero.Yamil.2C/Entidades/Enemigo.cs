﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Enemigo : Personaje
    {
        private string objetivo;

        public Enemigo(string nombre, List<EHabilidades> hab, string objetivo) : base(nombre, hab)
        {
            this.objetivo = objetivo;
        }

        protected override string Nombre
        {
            get
            {
                return String.Format("Soy {0} y los voy a ahcer puré", this.Nombre);
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine(this.objetivo);

            return sb.ToString();
        }
    }
}
