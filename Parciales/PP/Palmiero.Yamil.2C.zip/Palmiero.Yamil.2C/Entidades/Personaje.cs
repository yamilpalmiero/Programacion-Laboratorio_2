﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Personaje
    {
        public enum EHabilidades
        {
            Volar,
            Superfuerza,
            Resistencia,
            Rayos,
            Energia,
            InteligenciaSuperior,
            Sigilo,
            Astucia
        }

        private List<EHabilidades> listaHabilidades;
        protected string nombre;

        private Personaje()
        {
            this.listaHabilidades = new List<EHabilidades>();
        }
        public Personaje(string nombre, List<EHabilidades> habilidades) : this()
        {
            this.nombre = nombre;
        }

        private string ListaHabilidades
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                foreach (EHabilidades habilidad in listaHabilidades)
                {
                    sb.AppendLine(habilidad.ToString());
                }
                return sb.ToString();
            }
        }
        protected virtual string Nombre
        {
            get
            {
                return this.nombre;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(String.Format(this.Nombre));
            sb.AppendLine(String.Format(this.ListaHabilidades));

            return sb.ToString();
        }

        public static bool operator ==(List<Personaje> listaPersonajes, Personaje personaje)
        {
            foreach (Personaje p in listaPersonajes)
            {
                if (listaPersonajes.Contains(p))
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(List<Personaje> listaPersonajes, Personaje personaje)
        {
            return !(listaPersonajes == personaje);
        }
        public static List<Personaje> operator +(List<Personaje> listaPersonajes, Personaje personaje)
        {
            if (listaPersonajes != personaje)
            {
                listaPersonajes.Add(personaje);
            }
            return listaPersonajes;
        }
    }
}
