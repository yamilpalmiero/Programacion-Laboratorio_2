﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Avenger : Personaje
    {
        public enum EEquipamiento
        {
            Armadura,
            Escudo,
            Martillo,
            Arco,
            Transformacion,
            ArtesMarciales
        }

        private EEquipamiento equipamiento;

        public Avenger(string nombre, List<EHabilidades> hab, EEquipamiento equipo) : base(nombre, hab)
        {
            this.equipamiento = equipo;
        }

        protected override string Nombre
        {
            get
            {
                return String.Format("Mi nombre es {0} y si no puedo proteger la tierra, la vengaré", this.nombre);
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine(this.equipamiento.ToString());

            return sb.ToString();
        }
    }
}
